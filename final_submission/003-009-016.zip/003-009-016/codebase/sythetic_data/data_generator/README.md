Step 1. Place archive folder (from: kaggle/[prothom alo](https://www.kaggle.com/datasets/furcifer/bangla-newspaper-dataset)) at outside of the git repository

Step 2. Run correct_sentence_extractor.ipynb
